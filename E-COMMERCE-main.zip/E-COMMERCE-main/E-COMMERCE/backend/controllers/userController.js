import User from "../models/userModels.js";
import validator from "validator";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";




const createToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET);
};




// Route for user login

const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Check if user exists

    const user = await User.findOne({ email });
    if (!user) {
      return res.json({ success: false, message: "User does not exist" });
    }
    // Compare the provided password with the hashed password in the database

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.json({ success: false, message: "Invalid credentials" });
    }

    // Generate JWT token

    const token = createToken(user._id);
    res.json({
      success: true,
      message: "Login successful",
      token,
    });
  } catch (error) {
    console.error("Error in loginUser:", error);
    res.send("Server error");
  }

};

//Routes for user registration

const registerUser = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // checking if user already exists

    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.json({ success: false, message: "User already exists" });
    }

    // Validate email format

    if (!validator.isEmail(email)) {
      return res.json({ success: false, message: "Invalid email format" });
    }
    if (password.length < 8) {
      return res.json({
        success: false,
        message: "Password must be at least 6 characters long",
      });
    }

    // Hash the password before saving

    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user

    const newUser = new User({
      name,
      email,
      password: hashedPassword,
    });
    
    await newUser.save();

    // Generate JWT token

    const token = createToken(newUser._id);

    res.json({
      success: true,
      message: "User registered successfully",
      token,
    });

  } catch (error) {
    console.error("Error in registerUser:", error);
    res.send("Server error");
  }
};

// Route for admin login

const adminLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (email === process.env.ADMIN_EMAIL && password === process.env.ADMIN_PASSWORD) {
       const  token = jwt.sign(email+password, process.env.JWT_SECRET);
       return res.json({ success: true, message: "Admin login successful", token });
    } else {
       return res.json({ success: false, message: "Invalid admin credentials" });
    } 
  } catch (error) {
    console.error("Error in adminLogin:", error);
    res.send("Server error");
  }
 
};

export { loginUser, registerUser, adminLogin };
