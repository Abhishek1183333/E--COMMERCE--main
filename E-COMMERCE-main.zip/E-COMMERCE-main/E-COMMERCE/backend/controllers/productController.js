import Product from '../models/productModel.js';
import { v2 as cloudinary } from 'cloudinary';

// function for adding a new product

const addProduct = async (req, res) => {
  try {
    const { name, description, price, category, subcategory, sizes, bestseller } = req.body;
    const image1 =req.files.image1 && req.files.image1[0];
    const image2 =req.files.image2 && req.files.image2[0];
    const image3 =req.files.image3 && req.files.image3[0];
    const image4 =req.files.image4 && req.files.image4[0];

    const images = [image1, image2, image3, image4].filter(item => item !== undefined);

    let imagesUrl = await Promise.all(
      images.map(async (item) => {
        const result = await cloudinary.uploader.upload(item.path, {resource_type: "image"});
        return result.secure_url;
      })
    )

    const productData = {
      name,
      description,
      price: Number(price),
      category,
      subcategory,
      sizes,
      bestseller: bestseller === 'true' ? true : false,
      images: imagesUrl,
      date: Date.now()
    }

    console.log(productData);

    const product = new Product(productData);
    await product.save();


    
    res.json({ success: true, message: "Product added successfully" });
  } catch (error) {
    console.error("Error in addProduct:", error);
    res.json({ success: false, message: "Error adding product" });
  }
}

// function for list products

const listProducts = async (req, res) => {
  try {
    const products = await Product.find({});
    res.json({ success: true, products });
  } catch (error) {
    console.error("Error in listProducts:", error);
    res.json({ success: false, message: "Error fetching products" });
  }
}

// function for removing product

const removeProduct = async (req, res) => {
   try {
    const { productId } = req.body;
    await Product.findByIdAndDelete(productId);
    res.json({ success: true, message: "Product removed successfully" });
  } catch (error) {
    console.error("Error in removeProduct:", error);
    res.json({ success: false, message: "Error removing product" });
  }
}

// function for single product info

const singleProduct = async (req, res) => {
  try {
    const { productId } = req.body;
    const product = await Product.findById(productId);
    res.json({ success: true, product });
  } catch (error) {
    console.error("Error in singleProduct:", error);
    res.json({ success: false, message: "Error fetching product details" });
  }
}

export { addProduct, listProducts, removeProduct, singleProduct };