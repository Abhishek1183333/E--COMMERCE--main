import mongoose from "mongoose";

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  description: {    
    type: String,
    required: true,
  },    
    price: {
    type: Number,
    required: true,
  },
    images: {
    type: Array,
  },
    category: {
    type: String,
    required: true,
  },
    subcategory: {
    type: String,
    required: true,
  },
    sizes: {
    type: Array,
    required: true,
    },
    bestSeller: {
    type: Boolean,
    default: false,
    },
    date: {
    type: Number,
    default: false,
    },
});



const Product = mongoose.models.product || mongoose.model("Product", productSchema);
export default Product; 