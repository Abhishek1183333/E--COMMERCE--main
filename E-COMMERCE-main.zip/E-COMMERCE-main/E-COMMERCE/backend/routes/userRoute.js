import express from "express";
import { registerUser, loginUser, adminLogin } from "../controllers/userController.js";

const userRouter = express.Router();

// Register a new user
userRouter.post('/register', registerUser);
// User login
userRouter.post('/login', loginUser);
// Admin login
userRouter.post('/admin', adminLogin);

export default userRouter;